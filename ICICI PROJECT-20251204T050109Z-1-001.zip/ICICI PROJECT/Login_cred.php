<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PL-BANK</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        /* Animated Orange & White Background */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            background: linear-gradient(-45deg, #FFA500, #FFD580, #FFFFFF, #FFE4B5);
            background-size: 400% 400%;
            animation: gradientAnimation 8s ease infinite;
            opacity: 0;
            animation: fadeIn 1s ease-in forwards;
        }

        /* Background Animation */
        @keyframes gradientAnimation {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        /* Page Fade-in Effect */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .container {
            padding: 50px;
            color: #333;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
        }

        /* Stylish Button Section */
        .fixed-buttons {
            position: fixed;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 20px;
        }

        /* Custom Button Styles */
        .btn-custom {
            border-radius: 50px;
            font-weight: bold;
            font-size: 18px;
            padding: 12px 30px;
            border: none;
            color: white;
            cursor: pointer;
            transition: all 0.3s ease-in-out;
            position: relative;
            overflow: hidden;
        }

        /* User Button - Light Orange */
        #userBtn {
            background: linear-gradient(45deg, #FFA500, #FFB347);
            box-shadow: 0 5px 15px rgba(255, 165, 0, 0.4);
        }

        /* Admin Button - Darker Orange */
        #adminBtn {
            background: linear-gradient(45deg, #FF8C00, #FF6347);
            box-shadow: 0 5px 15px rgba(255, 140, 0, 0.4);
        }

        /* Button Hover Effects */
        .btn-custom:hover {
            transform: scale(1.1);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.3);
        }

        /* Button Glowing Effect */
        .btn-custom::after {
            content: "";
            position: absolute;
            top: 50%;
            left: 50%;
            width: 200%;
            height: 200%;
            background: rgba(255, 255, 255, 0.1);
            transition: all 0.4s ease-in-out;
            border-radius: 50%;
            transform: translate(-50%, -50%) scale(0);
        }

        .btn-custom:hover::after {
            transform: translate(-50%, -50%) scale(1);
        }
        body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    height: 100vh;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
    background: url('front.webp') center/cover no-repeat, 
                linear-gradient(-45deg, #FFA500, #FFD580, #FFFFFF, #FFE4B5);
    background-size: cover, 400% 400%;
    animation: gradientAnimation 8s ease infinite;
    opacity: 0;
    animation: fadeIn 1s ease-in forwards;
    background-blend-mode: overlay;
}

    </style>
</head>
<body>

    <div class="container">
        <h1 class="display-4 fw-bold">Welcome to PL-BANK</h1>
        <p class="lead">Choose your role below:</p>
    </div>

    <div class="fixed-buttons">
        <button id="userBtn" class="btn btn-custom">User</button>
        <button id="adminBtn" class="btn btn-custom">Admin</button>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        document.getElementById("userBtn").addEventListener("click", function() {
            window.location.href = "User_login.php";
        });

        document.getElementById("adminBtn").addEventListener("click", function() {
            window.location.href = "Admin_login.php";
        });
    </script>

</body>
</html>
