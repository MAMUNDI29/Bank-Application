<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Loan Application Form for Indian residents">
    <title>Loan Application - India</title>
    <style>
 :root {
            --primary-color: #FF6F00;
            --hover-color: #FF8C1A;
            --text-color: #333;
            --background-color: #ffffff;
            --shadow-color: rgba(0, 0, 0, 0.1);
        }

        body {
            font-family: Arial, sans-serif;
            background-color: var(--background-color);
            margin: 0;
            padding: 20px;
            color: var(--text-color);
            line-height: 1.6;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            width: min(90%, 800px);
            background-color: var(--background-color);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px var(--shadow-color);
            animation: fadeIn 0.5s ease-in-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        h1 {
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 30px;
            font-size: 28px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            font-size: 16px;
            margin-bottom: 8px;
            display: block;
            color: var(--text-color);
            font-weight: 600;
        }

        input, select {
            width: 100%;
            padding: 12px;
            font-size: 16px;
            border: 1px solid var(--primary-color);
            border-radius: 6px;
            box-sizing: border-box;
            transition: all 0.3s ease-in-out;
        }

        input:focus, select:focus {
            border-color: var(--hover-color);
            outline: none;
            box-shadow: 0 0 8px rgba(255, 111, 0, 0.3);
            transform: scale(1.02);
        }

        button {
            background-color: var(--primary-color);
            color: white;
            padding: 14px 30px;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s ease-in-out;
            display: block;
            width: 100%;
            text-align: center;
        }

        button:hover {
            background-color: var(--hover-color);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px var(--shadow-color);
        }

        button:active {
            transform: translateY(1px);
        }

        input[type="number"]::-webkit-outer-spin-button,
        input[type="number"]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        .home-link {
            text-align: center;
            margin-top: 20px;
        }

        .home-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-size: 16px;
            font-weight: bold;
            transition: color 0.3s ease-in-out;
        }

        .home-link a:hover {
            color: var(--hover-color);
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .container {
                width: 95%;
                padding: 20px;
            }

            button {
                font-size: 14px;
                padding: 12px;
            }
        }
        /* Root Variables for Theme Colors */
:root {
    --primary-color: #FF6B00;
    --primary-hover: #E65C00;
    --white: #ffffff;
    --gray: #f5f5f5;
    --dark-gray: #333;
}

/* Global Reset */
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: 'Poppins', sans-serif;
}

body {
    background: linear-gradient(135deg, var(--primary-color), var(--primary-hover));
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    padding: 20px;
}

.container {
    max-width: 800px;
    width: 100%;
    padding: 30px;
    background: var(--white);
    border-radius: 12px;
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    text-align: center;
    animation: fadeIn 0.8s ease-in-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

.header {
    background: var(--primary-color);
    color: var(--white);
    padding: 20px;
    border-radius: 10px 10px 0 0;
}

.form-group {
    margin-bottom: 1.5rem;
    text-align: left;
}

label {
    display: block;
    font-weight: bold;
    margin-bottom: 8px;
    color: var(--primary-color);
}

input, select, textarea {
    width: 100%;
    padding: 12px;
    border: 2px solid #ddd;
    border-radius: 8px;
    font-size: 1rem;
    transition: all 0.3s ease-in-out;
}

input:focus, select:focus, textarea:focus {
    border-color: var(--primary-color);
    box-shadow: 0 0 10px rgba(255, 111, 0, 0.3);
    outline: none;
}

.btn-submit, .btn-back {
    display: inline-block;
    background: var(--primary-color);
    color: var(--white);
    padding: 12px;
    font-size: 1.2rem;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease-in-out;
    width: 100%;
    font-weight: bold;
    margin-top: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.btn-submit:hover, .btn-back:hover {
    background: var(--primary-hover);
    transform: scale(1.05);
}

.message {
    padding: 15px;
    font-weight: bold;
    border-radius: 8px;
    text-align: center;
    margin-bottom: 20px;
    background-color: var(--primary-color);
    color: var(--white);
}

@media (max-width: 768px) {
    .container {
        padding: 20px;
    }
    .btn-submit, .btn-back {
        font-size: 1rem;
    }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Loan Application Form - India</h1>

        <?php if (isset($success_message)): ?>
            <div class="message success">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
            <div class="message error">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <form method="POST" novalidate>
            <div class="form-group">
                <label for="name">Full Name:</label>
                <input type="text" id="name" name="name" required 
                       minlength="2" maxlength="50" 
                       pattern="[A-Za-z\s]+" 
                       title="Please enter a valid name (letters and spaces only)"
                       value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label for="email">Email Address:</label>
                <input type="email" id="email" name="email" required 
                       pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" 
                       title="Please enter a valid email address"
                       value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
            </div>
            
            <div class="form-group">
                <label for="loan_type">Loan Type:</label>
                <select id="loan_type" name="loan_type" required>
                    <option value="">Select a loan type</option>
                    <option value="Personal" <?php echo (isset($_POST['loan_type']) && $_POST['loan_type'] == 'Personal') ? 'selected' : ''; ?>>Personal Loan</option>
                    <option value="Home" <?php echo (isset($_POST['loan_type']) && $_POST['loan_type'] == 'Home') ? 'selected' : ''; ?>>Home Loan</option>
                    <option value="Education" <?php echo (isset($_POST['loan_type']) && $_POST['loan_type'] == 'Education') ? 'selected' : ''; ?>>Education Loan</option>
                    <option value="Business" <?php echo (isset($_POST['loan_type']) && $_POST['loan_type'] == 'Business') ? 'selected' : ''; ?>>Business Loan</option>
                    <option value="Car" <?php echo (isset($_POST['loan_type']) && $_POST['loan_type'] == 'Car') ? 'selected' : ''; ?>>Car Loan</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="amount">Loan Amount (₹):</label>
                <input type="number" id="amount" name="amount" required 
                       min="1000" max="10000000" 
                       title="Please enter an amount between ₹1,000 and ₹1,00,00,000"
                       value="<?php echo isset($_POST['amount']) ? htmlspecialchars($_POST['amount']) : ''; ?>">
            </div>
            
            <button type="submit">Apply Now</button>
        </form>

        <div class="home-link">
            <a href="FRONT.html">Back to Home</a>
        </div>
    </div>
</body>
</html>
