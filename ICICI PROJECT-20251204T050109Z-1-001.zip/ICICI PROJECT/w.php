<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bank Wireframe</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; background: #f4f4f4; }
        .container { width: 80%; margin: auto; overflow: hidden; }
        .header, .footer { background: #333; color: #fff; text-align: center; padding: 10px; }
        .main { background: #fff; padding: 20px; margin-top: 10px; }
        .nav { background: #555; padding: 10px; text-align: center; }
        .nav a { color: white; text-decoration: none; padding: 10px; }
        .nav a:hover { background: #777; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Bank System</h1>
    </div>
    
    <div class="nav">
        <a href="#dashboard">Dashboard</a>
        <a href="#transfer">Fund Transfer</a>
        <a href="#history">Transaction History</a>
        <a href="#logout">Logout</a>
    </div>
    
    <div class="container">
        <div class="main">
            <h2>Welcome, User</h2>
            <p>Account Balance: $5000</p>
            <h3>Recent Transactions</h3>
            <ul>
                <li>Sent $200 to John Doe</li>
                <li>Received $150 from Alice</li>
            </ul>
        </div>
    </div>
    
    <div class="footer">
        <p>&copy; 2025 Bank System</p>
    </div>
</body>
</html>
