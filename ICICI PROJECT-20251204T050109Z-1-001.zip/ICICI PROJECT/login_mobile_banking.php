<?php
session_start();
$conn = new mysqli("localhost", "root", "", "pl_bank");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT password FROM Mobile_Banking WHERE User_Name = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($db_password);
        $stmt->fetch();

        if ($password === $db_password) { // Use password_verify() for hashed passwords
            $_SESSION['username'] = $username;
            header("Location: mobile_bank.php"); // Redirect to another page
            exit();
        } else {
            $error = "Invalid password!";
        }
    } else {
        $error = "User not found!";
    }

    $stmt->close();
}

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: FRONT.html");
    exit();
}

// Check if user is logged in
$loggedIn = isset($_SESSION['username']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mobile Banking</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            background: url('mobilebank.webp') no-repeat center center/cover;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            background: rgba(255, 255, 255, 0.9);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            width: 100%;
            text-align: center;
        }
        h2 {
            color: #F06B23;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }
        label {
            font-weight: bold;
            color: #333;
        }
        input[type="text"], input[type="password"], button {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            font-size: 16px;
        }
        input:focus {
            border-color: #F06B23;
            outline: none;
            box-shadow: 0 0 5px rgba(240, 107, 35, 0.5);
        }
        .btn {
            background: #F06B23;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 18px;
            transition: 0.3s;
        }
        .btn:hover {
            background: #d85d1a;
        }
        .link {
            display: block;
            margin-top: 10px;
            color: #F06B23;
            text-decoration: none;
        }
        .link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (!$loggedIn): ?>
            <h2>Mobile Banking Login</h2>
            <?php if (isset($error)): ?>
                <p style="color: red;"><?php echo $error; ?></p>
            <?php endif; ?>
            <form method="POST">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" name="username" id="username" placeholder="Enter your username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" name="password" id="password" placeholder="Enter your password" required>
                </div>
                <button type="submit" name="login" class="btn">Login</button>
                <a href="#" class="link">Forgot Password?</a>
            </form>
        <?php else: ?>
            <h2>Welcome, <?php echo $_SESSION['username']; ?>!</h2>
            <a href="?logout=true" class="btn">Logout</a>
        <?php endif; ?>
    </div>
</body>
</html>
