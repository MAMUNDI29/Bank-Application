<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pl_bank";

try {
    $conn = new PDO("mysql:host=$servername", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create database if not exists
    $conn->exec("CREATE DATABASE IF NOT EXISTS $dbname");
    $conn->exec("USE $dbname");
    
    // Create table if not exists
    $sql = "CREATE TABLE IF NOT EXISTS deposits (
        id INT AUTO_INCREMENT PRIMARY KEY,
        account_number VARCHAR(20) NOT NULL,
        account_holder VARCHAR(100) NOT NULL,
        deposit_amount DECIMAL(12,2) NOT NULL,
        deposit_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    $conn->exec($sql);
    
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Validate and sanitize input
        $account_number = filter_input(INPUT_POST, 'account_number', FILTER_SANITIZE_STRING);
        $account_holder = filter_input(INPUT_POST, 'account_holder', FILTER_SANITIZE_STRING);
        $deposit_amount = filter_input(INPUT_POST, 'deposit_amount', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

        // Validate inputs
        if (empty($account_number) || empty($account_holder) || empty($deposit_amount)) {
            throw new Exception("All fields are required");
        }

        if (!is_numeric($deposit_amount) || $deposit_amount <= 0) {
            throw new Exception("Please enter a valid deposit amount");
        }

        // Insert into database
        $stmt = $conn->prepare("INSERT INTO deposits (account_number, account_holder, deposit_amount) 
                              VALUES (:account_number, :account_holder, :deposit_amount)");
        
        $stmt->execute([
            ':account_number' => $account_number,
            ':account_holder' => $account_holder,
            ':deposit_amount' => $deposit_amount
        ]);

        $success_message = "Deposit of ₹" . number_format($deposit_amount, 2) . " has been successfully processed.";
        
    } catch (Exception $e) {
        $error_message = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bank Deposit</title>
    <style>
        :root {
            --primary-color: #FF6F00;
            --secondary-color: #FF8F00;
            --white: #ffffff;
            --light-gray: #f5f5f5;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            background-color: var(--light-gray);
        }

        .header {
            background-color: var(--primary-color);
            color: var(--white);
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 0 20px;
        }

        .deposit-form {
            background-color: var(--white);
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }

        .form-title {
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 1.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid var(--primary-color);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            color: #333;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 5px rgba(255,111,0,0.2);
        }

        .submit-btn {
            background-color: var(--primary-color);
            color: var(--white);
            padding: 1rem 2rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            font-size: 1.1rem;
            transition: background-color 0.3s ease;
        }

        .submit-btn:hover {
            background-color: var(--secondary-color);
        }

        .message {
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 4px;
            text-align: center;
            font-weight: bold;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .home-link {
            display: block;
            text-align: center;
            margin-top: 1rem;
            color: var(--primary-color);
            text-decoration: none;
            font-weight: bold;
        }

        .home-link:hover {
            color: var(--secondary-color);
        }

        .amount-info {
            font-size: 0.9rem;
            color: #666;
            margin-top: 0.5rem;
        }

        @media (max-width: 768px) {
            .container {
                margin: 1rem auto;
            }

            .deposit-form {
                padding: 1.5rem;
            }
        }
    :root {
        --primary-color: #FF6F00;
        --secondary-color: #FF8F00;
        --white: #ffffff;
        --light-gray: #f5f5f5;
        --dark-gray: #333;
    }

    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
        font-family: 'Poppins', sans-serif;
    }

    body {
        background: linear-gradient(135deg, #FF6F00, #FF8F00);
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        padding: 20px;
    }

    .container {
        max-width: 800px;
        width: 100%;
        padding: 30px;
        background-color: rgba(255, 255, 255, 0.9);
        border-radius: 12px;
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        text-align: center;
        animation: fadeIn 0.8s ease-in-out;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .form-title {
        font-size: 24px;
        font-weight: bold;
        color: var(--primary-color);
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 2px solid var(--primary-color);
        display: inline-block;
    }

    .form-group {
        margin-bottom: 1.5rem;
        text-align: left;
    }

    label {
        display: block;
        font-weight: bold;
        margin-bottom: 8px;
        color: var(--dark-gray);
    }

    input {
        width: 100%;
        padding: 12px;
        border: 2px solid #ddd;
        border-radius: 8px;
        font-size: 1rem;
        transition: all 0.3s ease-in-out;
    }

    input:focus {
        border-color: var(--primary-color);
        box-shadow: 0 0 10px rgba(255, 111, 0, 0.3);
        outline: none;
    }

    .submit-btn {
        background: linear-gradient(45deg, var(--primary-color), var(--secondary-color));
        color: var(--white);
        padding: 12px;
        font-size: 1.2rem;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s ease-in-out;
        width: 100%;
        font-weight: bold;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .submit-btn:hover {
        background: linear-gradient(45deg, var(--secondary-color), var(--primary-color));
        transform: scale(1.05);
    }

    .message {
        padding: 15px;
        font-weight: bold;
        border-radius: 8px;
        text-align: center;
        margin-bottom: 20px;
    }

    .success {
        background-color: #d4edda;
        color: #155724;
    }

    .error {
        background-color: #f8d7da;
        color: #721c24;
    }

    .home-link {
        display: inline-block;
        margin-top: 15px;
        font-size: 16px;
        color: var(--primary-color);
        font-weight: bold;
        text-decoration: none;
        transition: color 0.3s ease-in-out;
    }

    .home-link:hover {
        color: var(--secondary-color);
    }

    @media (max-width: 768px) {
        .container {
            padding: 20px;
        }

        .submit-btn {
            font-size: 1rem;
        }
    }

    </style>
</head>
<body>
    <div class="header">
        <h1>PL-Bank Deposit </h1>
    </div>

    <div class="container">
        <?php if (isset($success_message)): ?>
            <div class="message success">
                <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
            <div class="message error">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>

        <div class="deposit-form">
            <h2 class="form-title">Make a Deposit</h2>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-group">
                    <label for="account_number">Account Number:</label>
                    <input type="text" id="account_number" name="account_number" required
                           title="Please enter a valid account number"
                           value="<?php echo isset($_POST['account_number']) ? htmlspecialchars($_POST['account_number']) : ''; ?>">
                </div>

                <div class="form-group">
                    <label for="account_holder">Account Holder Name:</label>
                    <input type="text" id="account_holder" name="account_holder" required
                           pattern="[A-Za-z\s]+" title="Please enter a valid name (letters and spaces only)"
                           value="<?php echo isset($_POST['account_holder']) ? htmlspecialchars($_POST['account_holder']) : ''; ?>">
                </div>

                <div class="form-group">
                    <label for="deposit_amount">Deposit Amount (₹):</label>
                    <input type="number" id="deposit_amount" name="deposit_amount" required
                           min="1" step="0.01"
                           value="<?php echo isset($_POST['deposit_amount']) ? htmlspecialchars($_POST['deposit_amount']) : ''; ?>">
                    <div class="amount-info">Minimum deposit amount: ₹1</div>
                </div>

                <button type="submit" class="submit-btn">Process Deposit</button>
            </form>
        </div>

        <a href="FRONT.html" class="home-link">← Back to Home</a>
    </div>
</body>
</html>