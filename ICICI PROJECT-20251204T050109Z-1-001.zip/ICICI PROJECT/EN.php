<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entrepreneur Application</title>
    <meta name="description" content="Apply for a Entrepreneur loan with PL-BANK. Get the funding you need to launch or expand your business.">
    <meta name="keywords" content="Entrepreneur loan, loan application, small business funding,PL-BANK">
    <meta name="author" content="PL-BANK">

    <style>
        body {
            background-color: #fff7e6;
            font-family: sans-serif;
            margin: 0;
            padding: 0;
            line-height: 1.6;
        }

        form {
            background-color: #f0f0f0;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        header {
            background-color: #ff7300;
            color: white;
            padding: 1rem 0;
            text-align: center;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        header nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        header nav ul li {
            display: inline;
            margin: 0 1rem;
        }

        header nav ul li a {
            color: white;
            text-decoration: none;
        }

        main {
            padding-top: 60px;
        }

        section {
            padding: 2rem;
            text-align: center;
            scroll-margin-top: 60px;
        }

        .hero {
            background-color: #f0f0f0;
        }

        .button {
            background-color: rgb(255, 191, 0);
            color: white;
            padding: 0.5rem 1rem;
            text-decoration: none;
            border-radius: 5px;
        }

        .courses {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        .course {
            width: 300px;
            margin: 1rem;
            padding: 1rem;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .apply {
            max-width: 800px;
            margin: 2rem auto;
            background-color: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .apply form {
            max-width: 100%;
            margin: 0 auto;
            text-align: left;
            padding: 1rem;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
        }

        .apply label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: bold;
        }

        .apply input[type="text"],
        .apply input[type="email"],
        .apply input[type="number"],
        .apply input[type="file"],
        .apply textarea {
            width: 100%;
            padding: 0.5rem;
            margin-bottom: 1rem;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .apply button[type="submit"] {
            background-color: rgb(255, 162, 0);
            color: white;
            padding: 0.5rem 1rem;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        footer {
            background-color: #ff7300;
            color: white;
            text-align: center;
            padding: 1rem 0;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            header nav ul li {
                display: block;
                margin: 0.5rem 0;
            }

            .courses {
                flex-direction: column;
                align-items: center;
            }
        }
    </style>
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="EN.php">Apply Now</a></li>
                <li><a href="Contactus.html">Contact Us</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section id="apply" class="apply">
            <h2>Apply for a Bank Loan</h2>
            <p>Get the funding you need to launch your business.</p>
            
            <form action="submit.php" method="post" enctype="multipart/form-data">
                <fieldset>
                    <legend>Business Information</legend>
                    
                    <label for="businessName">Business Name:</label>
                    <input type="text" id="businessName" name="businessName" placeholder="Enter The Name:" required>
                    
                    <label for="ownerName">Owner Name:</label>
                    <input type="text" id="ownerName" name="ownerName" placeholder="Enter the Owner Name:" required>
                    
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" placeholder="Enter The Email:" required>
                </fieldset>
                
                <fieldset>
                    <legend>Loan Details</legend>
                    
                    <label for="loanAmount">Loan Amount (USD):</label>
                    <input type="number" id="loanAmount" name="loanAmount" min="1000" step="1000" placeholder="Enter The Amount:" required>
                    
                    <label for="loanPurpose">Purpose of Loan:</label>
                    <textarea id="loanPurpose" name="loanPurpose" rows="4" required></textarea>
                </fieldset>
                
                <fieldset>
                    <legend>Document Uploads</legend>
                    
                    <label for="businessPlan">Business Plan (PDF):</label>
                    <input type="file" id="businessPlan" name="businessPlan" accept=".pdf" required>
                    
                    <label for="financialStatements">Financial Statements (PDF):</label>
                    <input type="file" id="financialStatements" name="financialStatements" accept=".pdf" required>
                    
                    <label for="certificate">Education Certificate (PDF, JPG, PNG):</label>
                    <input type="file" id="certificate" name="certificate" accept=".pdf, .jpg, .jpeg, .png">
                </fieldset>
                
                <button type="submit">Submit Application</button>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 PL-BANK. All rights reserved.</p>
    </footer>
</body>
</html>