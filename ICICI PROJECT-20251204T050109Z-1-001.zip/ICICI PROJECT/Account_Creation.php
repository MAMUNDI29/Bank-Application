<?php
// Database connection (you'll need to configure these details)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pl_bank";

// Initialize variables
$message = "";

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Create a new database connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Capture form data and sanitize it
    $fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $account_type = mysqli_real_escape_string($conn, $_POST['account_type']);
    $initial_deposit = mysqli_real_escape_string($conn, $_POST['initial_deposit']);

    // Generate a unique account number
    do {
        $account_number = 'PL-' . rand(100000000, 999999999);
        $checkQuery = "SELECT * FROM accounts WHERE account_number='$account_number'";
        $result = $conn->query($checkQuery);
    } while ($result->num_rows > 0);

    // Insert data using prepared statements
    $stmt = $conn->prepare("INSERT INTO accounts (account_number, fullname, email, phone, address, account_type, balance) 
                            VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssd", $account_number, $fullname, $email, $phone, $address, $account_type, $initial_deposit);

    if ($stmt->execute()) {
        $message = "✅ Account created successfully!<br>Your Account Number is: <b>" . $account_number . "</b>";
    } else {
        $message = "❌ Error: Unable to create account. Please try again.";
    }

    // Close connections
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PL-BANK - Create Account</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #fff;
        }
        .header {
            background-color: #FF6B00;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .container {
            width: 80%;
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #FF6B00;
        }
        input[type="text"],
        input[type="email"],
        input[type="tel"],
        input[type="number"],
        select,
        textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #FF6B00;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .btn-submit {
            background-color: #FF6B00;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        .btn-submit:hover {
            background-color: #E65C00;
        }
        .btn-back {
            background-color: #FF6B00;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            font-size: 16px;
        }
        .btn-back:hover {
            background-color: #E65C00;
        }
        .message {
            margin-top: 20px;
            padding: 10px;
            border-radius: 4px;
            background-color: #FF6B00;
            color: white;
        }
        /* Root Variables for Theme Colors */
:root {
    --primary-color: #FF6B00;
    --primary-hover: #E65C00;
    --white: #ffffff;
    --gray: #f5f5f5;
    --dark-gray: #333;
}

/* Global Reset */
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: 'Poppins', sans-serif;
}

body {
    background: linear-gradient(135deg, var(--primary-color), var(--primary-hover));
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    padding: 20px;
}

.container {
    max-width: 800px;
    width: 100%;
    padding: 30px;
    background: var(--white);
    border-radius: 12px;
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    text-align: center;
    animation: fadeIn 0.8s ease-in-out;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

.header {
    background: var(--primary-color);
    color: var(--white);
    padding: 20px;
    border-radius: 10px 10px 0 0;
}

.form-group {
    margin-bottom: 1.5rem;
    text-align: left;
}

label {
    display: block;
    font-weight: bold;
    margin-bottom: 8px;
    color: var(--primary-color);
}

input, select, textarea {
    width: 100%;
    padding: 12px;
    border: 2px solid #ddd;
    border-radius: 8px;
    font-size: 1rem;
    transition: all 0.3s ease-in-out;
}

input:focus, select:focus, textarea:focus {
    border-color: var(--primary-color);
    box-shadow: 0 0 10px rgba(255, 111, 0, 0.3);
    outline: none;
}

.btn-submit, .btn-back {
    display: inline-block;
    background: var(--primary-color);
    color: var(--white);
    padding: 12px;
    font-size: 1.2rem;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s ease-in-out;
    width: 100%;
    font-weight: bold;
    margin-top: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.btn-submit:hover, .btn-back:hover {
    background: var(--primary-hover);
    transform: scale(1.05);
}

.message {
    padding: 15px;
    font-weight: bold;
    border-radius: 8px;
    text-align: center;
    margin-bottom: 20px;
    background-color: var(--primary-color);
    color: var(--white);
}

@media (max-width: 768px) {
    .container {
        padding: 20px;
    }
    .btn-submit, .btn-back {
        font-size: 1rem;
    }
}

    </style>
</head>
<body>
    <div class="header">
        <h1>PL-BANK</h1>
        <p>Create Your Bank Account</p>
    </div>
    
    <div class="container">
        <?php if($message): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>

        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group">
                <label for="fullname">Full Name:</label>
                <input type="text" id="fullname" name="fullname" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>

            <div class="form-group">
                <label for="phone">Phone Number:</label>
                <input type="tel" id="phone" name="phone" required>
            </div>

            <div class="form-group">
                <label for="address">Address:</label>
                <textarea id="address" name="address" required></textarea>
            </div>

            <div class="form-group">
                <label for="account_type">Account Type:</label>
                <select id="account_type" name="account_type" required>
                    <option value="">Select Account Type</option>
                    <option value="savings">Savings Account</option>
                    <option value="checking">Checking Account</option>
                    <option value="business">Business Account</option>
                </select>
            </div>

            <div class="form-group">
                <label for="initial_deposit">Initial Deposit Amount:</label>
                <input type="number" id="initial_deposit" name="initial_deposit" min="500" required>
            </div>

            <button type="submit" class="btn-submit">Create Account</button>
            <a href="FRONT.html" class="btn-back">Back</a>
        </form>
    </div>
</body>
</html>
