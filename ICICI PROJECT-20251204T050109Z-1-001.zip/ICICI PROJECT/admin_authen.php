<?php


// Database Connection
$host = "localhost";
$user = "root";
$pass = ""; // Change if your database has a password
$dbname = "pl_bank";

$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

// Create table if not exists
$sql = "CREATE TABLE IF NOT EXISTS Admin_Login(
    id INT AUTO_INCREMENT PRIMARY KEY,
    AdminName VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conn->query($sql);

// Handle Form Submission
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["admin_username"];
    $password = $_POST["admin_password"];

    // Check if user exists in DB
    $stmt = $conn->prepare("SELECT * FROM Admin_Login WHERE AdminName = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Redirect to FRONT.html if login is successful
        echo "<script>window.location.href='admin.php';</script>";
        exit();
    } else {
        $message = "<div class='alert alert-danger'>Invalid Username or Password! ❌</div>";
    }

    $stmt->close();
}
?>