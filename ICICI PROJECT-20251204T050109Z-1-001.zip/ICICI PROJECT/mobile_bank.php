<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PL-Pay - Mobile Banking</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #fff5eb;
            font-family: 'Arial', sans-serif;
        }

        .navbar {
            background-color: #f06b23 !important;
        }

        .navbar-brand {
            font-size: 24px;
            font-weight: bold;
            color: white !important;
        }

        .balance-card {
            background: linear-gradient(135deg, #f06b23, #ff914d);
            color: white;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
        }

        .balance-card h4 {
            font-size: 20px;
        }

        .balance-card h2 {
            font-size: 28px;
            font-weight: bold;
        }

        .btn-orange {
            background-color: #f06b23;
            color: white;
            font-weight: bold;
        }

        .btn-orange:hover {
            background-color: #d85d1a;
            color: white;
        }

        .transaction-list {
            background: white;
            border-radius: 10px;
            padding: 15px;
            margin-top: 20px;
        }

        .transaction-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }

        .transaction-item:last-child {
            border-bottom: none;
        }
        .footer {
            background-color: #f06b23 !important;
            color: white;
            text-align: center;
            padding: 20px;
            width: 100%;
        }
    </style>
</head>
<body>
    <?php
   // Database connection (you'll need to configure these details)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pl_bank";

// Initialize variables
$message = "";

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Create a new database connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

}
    ?>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
    <div class="container">
        <a class="navbar-brand" href="#">PL-PAY</a>
    </div>
</nav>

<!-- Main Content -->
<div class="container mt-4">
    <!-- Balance Card -->
    <div class="balance-card">
        <h4 style="color: black">Available Balance</h4>
        <h6 >29012008</h6>
       
      
    </div>

    <!-- Quick Actions -->
    <div class="row text-center mt-4">
        <div class="col-6">
            <button class="btn btn-orange w-100 p-3 rounded" style="color: black" onclick=send()>Send Money</button>
        </div>
        <div class="col-6">
            <button class="btn btn-orange w-100 p-3 rounded" style="color: black" onclick = pay()>Pay Bills</button>
        </div>
    </div>

    <!-- Transaction History -->
    <div class="transaction-list mt-4">
        <h5 class="text-center" style="color: black">Recent Transactions</h5>
        <div class="transaction-item">
            <span>Amazon Purchase</span>
            <span style="color: red;" style="color: black">-₹1,200</span>
        </div>
        <div class="transaction-item">
            <span>UPI Transfer</span>
            <span style="color: green;" style="color: black">+₹2,500</span>
        </div>
        <div class="transaction-item">
            <span style="color: black">Electricity Bill</span>
            <span style="color: red;">-₹600</span>
        </div>
    </div>
</div>
<script>
    function send(){
        window.location.href = "Deposite.php";
    }
    function pay(){
        window.location.href = "Billpay.html";
    }
    </script><br><br><br><br><br><br><br><br>
    <div class="footer">
        <p>&copy; 2025 PL-BANK. All rights reserved.</p>
    </div>

</body>
</html>