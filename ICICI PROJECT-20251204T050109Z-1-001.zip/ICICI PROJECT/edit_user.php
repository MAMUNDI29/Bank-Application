<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php"); // Redirect if not logged in
    exit();
}

$conn = new mysqli("localhost", "root", "", "test_db");

if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch user data
    $stmt = $conn->prepare("SELECT * FROM project WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
}

if (isset($_POST["name"], $_POST["d_b"], $_POST["ph_num"], $_POST["address"], $_POST["pan"])) {
    $name = trim($_POST["name"]);
    $d_b = trim($_POST["d_b"]);
    $p_n = trim($_POST["ph_num"]);
    $ad = trim($_POST["address"]);
    $pan = trim($_POST["pan"]);

    // Update user data
    $stmt = $conn->prepare("UPDATE project SET NAME = ?, date_of_birth = ?, mobile_no = ?, address = ?, pan = ? WHERE id = ?");
    $stmt->bind_param("sssssi", $name, $d_b, $p_n, $ad, $pan, $id);

    if ($stmt->execute()) {
        header("Location: admin_dashboard.php"); // Redirect to the admin dashboard
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #f0f0f0, #e8e8e8);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .form-container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        .form-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-container label {
            display: block;
            margin-bottom: 5px;
        }
        .form-container input, .form-container textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .form-container input[type="submit"] {
            background: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        .form-container input[type="submit"]:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Edit User</h2>
        <form action="edit_user.php?id=<?php echo $id; ?>" method="post">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo $user['NAME']; ?>" required>

            <label for="d_b">Date of Birth:</label>
            <input type="date" id="d_b" name="d_b" value="<?php echo $user['date_of_birth']; ?>" required>

            <label for="ph_num">Phone Number:</label>
            <input type="text" id="ph_num" name="ph_num" value="<?php echo $user['mobile_no']; ?>" required>

            <label for="address">Address:</label>
            <textarea id="address" name="address" required><?php echo $user['address']; ?></textarea>

            <label for="pan">PAN:</label>
            <input type="text" id="pan" name="pan" value="<?php echo $user['pan']; ?>" required>

            <input type="submit" value="Update">
        </form>
    </div>
</body>
</html>