<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GlamUp & Go: Instant Credit for Your Beauty Needs</title>
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            margin: 0;
            font-family: 'Montserrat', sans-serif;
            background: linear-gradient(135deg, #f0f0f0, #e8e8e8);
            color: #333;
            align-items: center;
        }

        header {
            background: linear-gradient(to right, #FF5733, #F0A500);
            color: white;
            text-align: center;
            padding: 15px 0;
            width: 100%;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .nav-links {
            display: flex;
            justify-content: center;
            gap: 15px;
            padding: 10px 0;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            transition: opacity 0.3s;
        }

        .nav-links a:hover {
            opacity: 0.7;
        }

        #credit-options {
            padding: 20px;
            text-align: center;
            width: 90%;
            max-width: 1200px;
        }

        .option {
            background-color: white;
            border: 1px solid #ddd;
            padding: 20px;
            margin: 15px;
            display: inline-block;
            width: 250px;
            border-radius: 10px;
            transition: transform 0.3s ease-in-out, box-shadow 0.3s;
        }

        .option:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .learn-more {
            background-color: #ff9100;
            color: white;
            border: none;
            padding: 10px 20px;
            margin-top: 10px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .learn-more:hover {
            background-color: #c26518;
        }

        .modal {
            display: none;
            position: fixed;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            align-items: center;
            justify-content: center;
        }

        .modal-content {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
            width: 80%;
            max-width: 500px;
            text-align: center;
        }

        .close {
            position: absolute;
            right: 20px;
            top: 10px;
            font-size: 24px;
            cursor: pointer;
        }

        footer {
            background-color: #f8d3bb;
            text-align: center;
            padding: 20px 0;
            color: #333;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <h3>PL BANK Credit Cards</h3>
        <nav class="nav-links">
            <a href="pl_bank.php">⇚ Home</a>
            <a href="pro_pictur.html">Explore Our Cards</a>
            <a href="pro_aces.php">Benefits</a>
            <a href="pro_cre_r.php">Offers</a>
            <a href="pro_login.php">Apply now</a>
            <a href="pro_crdit_re.html">Rules</a>
        </nav>
    </header>

    <main id="credit-options">
        <h2>Instant Credit Options</h2>
        <div class="option" data-type="BNPL">
            <h3>Buy Now, Pay Later (BNPL)</h3>
            <p>Perfect for small, immediate purchases. Interest-free for short terms.</p>
            <button class="learn-more">Learn More</button>
        </div>
        <div class="option" data-type="DigitalCredit">
            <h3>Digital Credit</h3>
            <p>Quick approval via mobile apps. Ideal for unexpected bills.</p>
            <button class="learn-more">Learn More</button>
        </div>
    </main>

    <div id="modal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <div id="modal-text"></div>
        </div>
    </div>

    <footer>
        <p>&copy; 2024 GlamUp & Go. All rights reserved.</p>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const options = document.querySelectorAll('.option');
            const modal = document.getElementById('modal');
            const modalText = document.getElementById('modal-text');
            const closeBtn = document.querySelector('.close');

            options.forEach(option => {
                option.addEventListener('click', function() {
                    const type = this.dataset.type;
                    let content = '';
                    switch (type) {
                        case 'BNPL':
                            content = '<p>Buy now, pay later. Ideal for small purchases.</p>';
                            break;
                        case 'DigitalCredit':
                            content = '<p>Fast digital credit via mobile apps.</p>';
                            break;
                        default:
                            content = '<p>More information coming soon.</p>';
                    }
                    modalText.innerHTML = content;
                    modal.style.display = 'flex';
                });
            });

            closeBtn.onclick = function() {
                modal.style.display = 'none';
            };

            window.onclick = function(event) {
                if (event.target === modal) {
                    modal.style.display = 'none';
                }
            };
        });
    </script>
</body>
</html>