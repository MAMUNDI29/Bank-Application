<html>

<?php
// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pl_bank";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to sanitize form data
function sanitize($data) {
    global $conn;
    return mysqli_real_escape_string($conn, trim($data));
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $businessName = sanitize($_POST["businessName"]);
    $ownerName = sanitize($_POST["ownerName"]);
    $email = sanitize($_POST["email"]);
    $loanAmount = sanitize($_POST["loanAmount"]);
    $loanPurpose = sanitize($_POST["loanPurpose"]);
    $targetDir = __DIR__ . "/uploads/";

    if (!is_dir($targetDir)) {
        if (!mkdir($targetDir, 0775, true)) {
            die("Failed to create directory: " . $targetDir);
        }
    }
    
    if (!is_writable($targetDir)) {
        echo "Directory is not writable: " . $targetDir . "<br>";
        echo "Temporary directory: " . ini_get('upload_tmp_dir');
        die(); // Halt execution after displaying the messages
    }

    // File upload handling
    $targetDir = "uploads/";  // Directory where files will be stored
    $targetDir = "uploads/";  // Directory where files will be stored
    
    // Function to handle file uploads
    function uploadFile($file, $targetDir, $field) {
        $fileName = basename($file["name"]);
        $targetFilePath = $targetDir . $fileName;
        $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
    
        // Allow certain file formats
        $allowTypes = array('pdf', 'jpg', 'jpeg', 'png');
        if(in_array($fileType, $allowTypes)){
            // Upload file to server
            if(move_uploaded_file($file["tmp_name"], $targetFilePath)){
                return $targetFilePath;
            } else {
                $error = error_get_last();
                echo "Sorry, there was an error uploading your " . $field . ". Error: " . $error['message'];
                return null;
            }
        } else {
            echo 'Sorry, only PDF, JPG, JPEG, & PNG files are allowed for ' . $field . '.';
            return null;
        }
    }

    // Upload files
    $businessPlanPath = uploadFile($_FILES["businessPlan"], $targetDir, "business plan");
    $financialStatementsPath = uploadFile($_FILES["financialStatements"], $targetDir, "financial statements");
    $certificatePath = uploadFile($_FILES["certificate"], $targetDir, "certificate");

    // Prepare and execute SQL query
    $sql = "INSERT INTO entrepreneur (businessName, ownerName, email, loanAmount, loanPurpose, businessPlan, financialStatements, certificate) 
            VALUES ('$businessName', '$ownerName', '$email', '$loanAmount', '$loanPurpose', '$businessPlanPath', '$financialStatementsPath', '$certificatePath')";

    if ($conn->query($sql) === TRUE) {
       echo "alert('Form Has Submitted Successfully')";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
