<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "pl_bank";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM accounts;
$result=$conn->query(sql);
if ($row = $result->fetch_assoc()) {
    echo "<p><strong>Name:</strong> " . htmlspecialchars($row['name']) . "</p>";
    echo "<p><strong>Email:</strong> " . htmlspecialchars($row['email']) . "</p>";
    echo "<p><strong>Phone:</strong> " . htmlspecialchars($row['phone']) . "</p>";
    echo "<p><strong>Account Number:</strong> " . htmlspecialchars($row['account_number']) . "</p>";
} else {
    echo "<p class='text-danger'>No profile data found.</p>";
}

$stmt->close();
$conn->close();
?>
