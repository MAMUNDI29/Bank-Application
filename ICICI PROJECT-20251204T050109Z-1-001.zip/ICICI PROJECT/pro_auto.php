<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auto Generate Credit Card</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background: linear-gradient(135deg, #f0f0f0, #e8e8e8);
            text-align: center;
            padding: 50px;
        }
        .card-number {
            font-size: 24px;
            font-weight: bold;
        }
    </style>
</head>
<body>

<header>
    <h3>Credit Card Number Generation</h3>
</header>

<div class="container">

<?php
$creditCardNumber = str_pad(mt_rand(0, 999999999), 9, '0', STR_PAD_LEFT);
echo "<p>Your new credit card number is: <span class='card-number'>$creditCardNumber</span></p>";
?>

</div>

<footer>
    <p>© 2024 PL Bank. All rights reserved.</p>
</footer>

</body>
</html>