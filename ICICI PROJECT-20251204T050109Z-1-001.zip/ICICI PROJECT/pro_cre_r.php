<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Credit Card Rules & Regulations</title>
    <link rel="stylesheet" href="style.css">
    <style>
    body {
        
        background: linear-gradient(135deg, #f0f0f0, #e8e8e8);
            text-align: center;
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            padding: 0;
            color: #333; background: linear-gradient(135deg, #f0f0f0, #e8e8e8);
            text-align: center;
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            padding: 0;
            color: #333;
    }
    .credit-card-background {
            background: linear-gradient(to right, #FF5733, #F0A500);
            padding: 5px 5px;
            color: white;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
            font-size: 1.1em;
            height: 25%;
            
        }
        h3{
            margin-left: 20.0em;
        }

        /* Style for links within credit card background */


    
    .hero {
        background: linear-gradient(to right, #FF5733, #F0A500);
        color: #fff;
        text-align: center;
        padding: 5px 5px;
        margin-top: 0%;
    }
    
    .hero h1 {
        margin-bottom: 10px;
    }
    
    .content {
        max-width: 900px;
        margin: 20px auto;
        padding: 0 20px;
    }
    
    .rule-section {
        background-color: #fff;
        border-radius: 8px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    
    .rule-section h2 {
        color: #ffa600;
        margin-bottom: 15px;
    }
    
    .rule-section p {
        margin-bottom: 10px;
    }
    
    .example {
        color: #ff4949;
        font-weight: bold;
    }
    
    .rule-section ul {
        list-style-type: none;
        padding-left: 0;
    }
    
    .rule-section li {
        margin-bottom: 10px;
    }
    
    .tips ul {
        list-style-type: none;
    }
    
    /* Responsive Design */
    @media (max-width: 768px) {
        .hero {
            padding: 30px 10px;
        }
    
        .content {
            padding: 0 10px;
        }
    
        .rule-section h2 {
            font-size: 1.2em;
        }

    }
    a{
            color: white;
            padding: 10px;
        }
        .a1 {
            display:ruby-base-container;
            padding: 5px 5px;
           
            
            text-decoration: none;
            font-weight: bold;
            border-radius: 5px;
            text-align: end;
            transition: background 0.3s;
            margin-left: 1px;
            float: inline-end;
             /* Center and space out footer links */
            width: 35 0px;
          

        }

        .a1:hover {
            background-color: none;
        }
        /* Fixed footer styles */
        footer {
            background: #333;
            color: white;
            padding: 0px 0;
            position: flex;
            bottom: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        </style>
</head>

<body>
<header class="hero">
<div class="credit-card-background">
<div class="a1">  
        <abbr title="Back to Credit Card Home page."><a href="pl_bank.php"><h5>⇚</h5></a></abbr>
         <a href="pro_pictur.html">Explore Our Cards</a>
            <a href="pro_aces.php">Benefits</a>
            <a href="pro_cre_r.php">Offers</a>
            <a href="pro_login.php">Apply now</a>
            <a href="pro_crdit_re.html">Rules</a>
            </div>
<h3>PL BANK Credit Cards</h3>
        <h1>Credit Card Rules & Regulations</h1>
        </div>
    </header>

    <main class="content">
        <section class="rule-section">
            <h2>1. Minimum Payment Rule</h2>
            <p>Every month, you must pay at least the minimum amount due (usually 5% of the total outstanding balance). Paying only the minimum will result in interest charges on the remaining balance.</p>
            <p class="example">✅ Example: If your bill is ₹10,000, and the minimum due is ₹500 (5%), paying only ₹500 will result in interest charges on the remaining ₹9,500.</p>
        </section>

        <section class="rule-section">
            <h2>2. Interest Charges on Outstanding Balance</h2>
            <p>If you do not pay the full bill, the remaining balance will be charged high interest (15%-48% annually). If you pay the full amount on time, no interest will be charged.</p>
            <p class="example">✅ Example: If you opt for EMI or cash withdrawal, extra interest and processing fees will apply.</p>
        </section>

        <section class="rule-section">
            <h2>3. Credit Limit Usage</h2>
            <p>Each credit card comes with a credit limit set by the bank. Using 30%-50% of your credit limit is recommended to maintain a good credit score.</p>
            <p class="example">✅ Example: If your credit limit is ₹1,00,000, spending ₹30,000 - ₹50,000 per month is ideal.</p>
        </section>

        <section class="rule-section">
            <h2>4. Late Payment Fees & Penalties</h2>
            <p>If you miss the due date, the bank will charge a late fee, and interest will continue to accumulate.</p>
            <p class="example">✅ Example: If your bill is ₹20,000 and you miss the due date, the bank may charge a late fee of ₹500 - ₹1,000, plus interest.</p>
        </section>

        <section class="rule-section">
            <h2>5. Grace Period (Interest-Free Days)</h2>
            <p>Most credit cards offer a grace period (45-50 days) before interest is charged. If you pay within this period, no interest will be applied.</p>
            <p class="example">✅ Example: If you make a purchase on April 1, and your payment due date is May 15, you can repay without interest.</p>
        </section>

        <section class="rule-section">
            <h2>6. Reward Points & Cashback Rules</h2>
            <p>Many credit cards offer reward points or cashback on purchases. Points should be redeemed before expiry for maximum benefits.</p>
            <p class="example">✅ Example: 10,000 reward points can be converted into a ₹1,000 shopping voucher.</p>
        </section>

        <section class="rule-section">
            <h2>7. Impact on Credit Score (CIBIL Score)</h2>
            <p>A good credit score (750+) helps in getting loans and higher credit limits. Late payments, high credit usage, and only paying the minimum due will reduce your credit score.</p>
            <p class="example">✅ Example: If you regularly pay on time, banks may increase your credit limit or offer lower interest rates on loans.</p>
        </section>

        <section class="rule-section">
            <h2>8. Common Mistakes to Avoid</h2>
            <ul>
                <li>❌ Maxing out your credit limit – Leads to a poor credit score and high interest charges.</li>
                <li>❌ Paying only the minimum due – Increases debt over time due to compounding interest.</li>
                <li>❌ Frequent EMI & Cash Withdrawals – Attracts high interest and extra fees.</li>
                <li>❌ Sharing your credit card details – Increases the risk of fraud.</li>
            </ul>
        </section>

        <section class="rule-section tips">
            <h2>📌 Important Tips</h2>
            <ul>
                <li>✔️ Always pay your full bill on time to avoid interest charges.</li>
                <li>✔️ Set up Auto-Pay to never miss due dates.</li>
                <li>✔️ Use your credit card wisely to build a strong credit score.</li>
                <li>✔️ Read the terms & conditions carefully before using any offers.</li>
            </ul>
        </section>
    </main>
    <footer>
        <p>© 2024 PL Bank. All rights reserved.</p><a href="pro_login.php">Apply now</a>
                
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
    const exampleSections = document.querySelectorAll('.example');

    exampleSections.forEach(section => {
        section.style.display = 'none'; // Initially hide examples

        const parentSection = section.parentElement;
        const heading = parentSection.querySelector('h2');

        heading.addEventListener('click', () => {
            if (section.style.display === 'none' || section.style.display === '') {
                section.style.display = 'block';
            } else {
                section.style.display = 'none';
            }
        });
    });
});
    </script>
</body>
</html>