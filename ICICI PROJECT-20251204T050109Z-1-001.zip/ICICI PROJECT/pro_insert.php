<?php
session_start(); // Start the session to store user data

// Database connection details
$host = "localhost";
$username = "root";
$password = "";
$database = "pl_bank";

// Create a connection to the database
$conn = new mysqli($host, $username, $password, $database);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if all required fields are set
if (isset($_POST["name"], $_POST["d_b"], $_POST["ph_num"], $_POST["address"], $_POST["pan"])) {
    // Sanitize and validate user input
    $name = trim($_POST["name"]);
    $d_b = trim($_POST["d_b"]);
    $p_n = trim($_POST["ph_num"]);
    $ad = trim($_POST["address"]);
    $pan = trim($_POST["pan"]);

    // Validate input (example: check if phone number is numeric and has 10 digits)
    if (!preg_match("/^\d{10}$/", $p_n)) {
        die("Invalid phone number. Please enter a 10-digit number.");
    }

    // Validate PAN (example: check if PAN is alphanumeric and has 10 characters)
    if (!preg_match("/^[A-Za-z0-9]{10}$/", $pan)) {
        die("Invalid PAN. Please enter a valid 10-character PAN.");
    }

    // Prepare SQL statement to prevent SQL injection
    $sql = "INSERT INTO Credit_cards (NAME, date_of_birth, mobile_no, address, pan) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }

    // Bind parameters to the prepared statement
    $stmt->bind_param("sssss", $name, $d_b, $p_n, $ad, $pan);

    // Execute the statement
    if ($stmt->execute()) {
        $_SESSION['name'] = $name; // Store the user's name in the session
        header("Location: pro_fni.php"); // Redirect to the next page
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
} else {
    echo "All fields are required.";
}

// Close the database connection
$conn->close();
?>