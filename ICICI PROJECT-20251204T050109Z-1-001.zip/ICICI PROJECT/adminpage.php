
<?php


// Database Connection
$host = "localhost";
$user = "root";
$pass = ""; // Change if your database has a password
$dbname = "pl_bank1";

$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

// Create table if not exists
$sql = "CREATE TABLE IF NOT EXISTS Admin_Login(
    id INT AUTO_INCREMENT PRIMARY KEY,
    AdminName VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    login_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conn->query($sql);

// Handle Form Submission
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["admin_username"];
    $password = $_POST["admin_password"];

    // Check if user exists in DB
    $stmt = $conn->prepare("SELECT * FROM Admin_Login WHERE AdminName = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Redirect to FRONT.html if login is successful
        echo "<script>window.location.href='admin.php';</script>";
        exit();
    } else {
        $message = "<div class='alert alert-danger'>Invalid Username or Password! ❌</div>";
    }

    $stmt->close();
}
?><?php
// Database Connection
$conn = new mysqli("localhost", "root", "", "pl_bank");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all tables
$query = "SHOW TABLES";
$result = $conn->query($query);
$tables = [];
while ($row = $result->fetch_array()) {
    $tables[] = $row[0];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bank Admin Dashboard</title>
    
    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    
    <style>
        body {
            background: linear-gradient(135deg, #ff9800, #ff5722);
            font-family: 'Arial', sans-serif;
            color: white;
            min-height: 100vh;
            display: flex;
            overflow: hidden;
        }
        .wrapper {
            display: flex;
            width: 100%;
            height: 100vh;
            overflow: hidden;
        }
        .sidebar {
            width: 260px;
            background: white;
            color: #ff9800;
            padding: 20px;
            height: 100vh;
            display: flex;
            flex-direction: column;
            box-shadow: 3px 0 10px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
            align-items: center;
        }
        .bank-logo {
            width: 50px; /* Adjust size */
            height: 50px;
            border-radius: 50%; /* Makes it circular */
            object-fit: cover; /* Ensures the image is properly fitted */
            display: block;
            margin-bottom: 10px;
        }
        .sidebar h2 {
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            color: #ff5722;
            margin-bottom: 20px;
        }
        .sidebar button {
            width: 100%;
            background: #ff9800;
            color: white;
            border: none;
            padding: 12px;
            margin: 5px 0;
            font-size: 16px;
            font-weight: bold;
            border-radius: 6px;
            transition: all 0.3s ease-in-out;
        }
        .sidebar button:hover {
            background: #e68900;
            transform: scale(1.08);
        }
        .main-content {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            padding: 15px 20px;
            color: #ff5722;
            font-size: 22px;
            font-weight: bold;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .logout-btn {
            background: #ff5722;
            color: white;
            border: none;
            padding: 10px 18px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: all 0.3s ease;
        }
        .logout-btn:hover {
            background: #e64a19;
            transform: scale(1.1);
        }
        .content {
            background: white;
            padding: 20px;
            margin-top: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            min-height: 400px;
            color: black;
            overflow-x: auto;
        }
        .table-container {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            border-radius: 10px;
            overflow: hidden;
        }
        table th {
            background: #ff9800;
            color: white;
            text-align: left;
            padding: 10px;
        }
        table td {
            padding: 10px;
            border-bottom: 1px solid #ddd;
        }
        table tbody tr:hover {
            background-color: #ffe0b2;
            transition: all 0.3s ease-in-out;
        }
        .title {
            font-size: 24px;
            font-weight: bold;
            color: #ff5722;
            text-align: center;
            margin-bottom: 15px;
        }
        @media (max-width: 768px) {
            .wrapper {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
                height: auto;
            }
            .main-content {
                overflow-y: auto;
            }
            .header {
                flex-direction: column;
                text-align: center;
            }
            .logout-btn {
                margin-top: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <div class="sidebar">
            <!-- Bank Logo -->
            <img src="pl_logo.jfif" alt="PL-BANK Logo" class="bank-logo">
            <h2>PL Bank</h2>

            <?php foreach ($tables as $table): ?>
                <button class="btn btn-block" onclick="loadTableData('<?php echo $table; ?>')">
                    <i class="fas fa-table"></i> <?php echo ucfirst($table); ?>
                </button>
            <?php endforeach; ?>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header d-flex justify-content-between">
                <h1>Bank Admin Dashboard</h1>
                <button onclick="logout()" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </button>
            </div>
            <div class="content" id="content-area">
                <h2 class="title">Select a table to view data</h2>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        function loadTableData(tableName) {
            let content = document.getElementById('content-area');
            content.innerHTML = "<h2 class='title'>Loading...</h2>";

            let xhr = new XMLHttpRequest();
            xhr.open("GET", "fetch_table.php?table=" + tableName, true);
            xhr.onload = function () {
                if (xhr.status === 200) {
                    content.innerHTML = "<h2 class='title'>" + tableName.charAt(0).toUpperCase() + tableName.slice(1) + "</h2>" + xhr.responseText;
                }
            };
            xhr.send();
        }

        function logout() {
            if (confirm("Are you sure you want to logout?")) {
                alert("Logging out...");
                window.location.href = "Login_cred.php";
            }
        }
    </script>
</body>
</html>
