<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "pl_bank";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create table if not exists
$conn->query("CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
    $hash = password_hash($password, PASSWORD_DEFAULT); // Encrypt password

    $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $hash);

    if ($stmt->execute()) {
        $message = "<div class='alert alert-success'>Registered successfully! 🎉</div>";
    } else {
        $message = "<div class='alert alert-danger'>Username already taken! ❌</div>";
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Sign Up</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            background: linear-gradient(-45deg, #FF4500, #FF8C00, #FFEFD5, #FFFFFF);
            background-size: 400% 400%;
            animation: gradientMove 8s ease infinite;
        }
        @keyframes gradientMove {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        .brand-name {
            font-size: 3rem;
            font-weight: bold;
            color: #FF4500;
            text-shadow: 3px 3px 10px rgba(255, 69, 0, 0.3);
            margin-bottom: 20px;
        }
        .login-box {
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border-radius: 15px;
            padding: 40px;
            width: 350px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }
        .form-control {
            border-radius: 25px;
            border: none;
            padding: 12px;
            margin-bottom: 15px;
            background: rgba(255, 255, 255, 0.5);
        }
        .btn-login {
            background: linear-gradient(45deg, #FF4500, #FF6347);
            border: none;
            color: white;
            padding: 12px;
            width: 100%;
            border-radius: 25px;
            font-weight: bold;
            cursor: pointer;
        }
        .btn-login:hover {
            transform: scale(1.05);
            box-shadow: 0 5px 15px rgba(255, 69, 0, 0.3);
        }
        .back-btn {
            display: block;
            margin-top: 15px;
            text-decoration: none;
            color: #FF4500;
            font-weight: bold;
        }
    </style>
<body class="d-flex justify-content-center align-items-center vh-100 bg-light">
    <center><strong><h2>Welcome to PL-BANK</h2></strong></center>
    <br>
    <div class="card p-4 shadow" style="width: 350px;">
        <h3 class="text-center">Sign Up</h3>
        <?= $message ?>
        <form method="POST">
            <input type="text" name="username" class="form-control mb-3" placeholder="Username" required>
            <input type="password" name="password" class="form-control mb-3" placeholder="Password" required>
            <button type="submit" class="btn btn-success w-100">Register</button>
        </form>
        <p class="text-center mt-3">Already registered? <a href="User_login.php">Login</a></p>
    </div>
</body>
</html>
