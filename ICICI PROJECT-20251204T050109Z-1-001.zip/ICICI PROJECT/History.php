<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PL Bank - Transaction History</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            background-color: #f2f2f2;
            color: #333;
            padding-bottom: 50px;
        }

        header {
            background-color: #FF8C00;
            color: white;
            padding: 30px 20px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        h1 {
            font-size: 36px;
            font-weight: 700;
        }

        .container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 6px 10px rgba(0, 0, 0, 0.1);
        }

        .search-form {
            display: flex;
            justify-content: space-between;
            margin-bottom: 30px;
        }

        .search-input {
            width: 75%;
            padding: 15px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s ease;
        }

        .search-input:focus {
            border-color: #FF8C00;
        }

        .search-btn {
            width: 20%;
            padding: 15px;
            background-color: #FF8C00;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .search-btn:hover {
            background-color: #e67e00;
        }

        .transaction-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .transaction-table th,
        .transaction-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
            font-size: 16px;
        }

        .transaction-table th {
            background-color: #FF8C00;
            color: white;
        }

        .transaction-table td {
            background-color: #fafafa;
        }

        .transaction-table tr:hover {
            background-color: #ffecdb;
        }

        .transaction-status {
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
        }

        .transaction-status.success {
            background-color: #2ecc71;
            color: white;
        }

        .transaction-status.failed {
            background-color: #e74c3c;
            color: white;
        }

        .transaction-status.pending {
            background-color: #f39c12;
            color: white;
        }

        .pagination {
            margin-top: 30px;
            display: flex;
            justify-content: center;
            gap: 10px;
        }

        .pagination button {
            padding: 10px 20px;
            border: 1px solid #FF8C00;
            background-color: white;
            color: #FF8C00;
            font-size: 16px;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .pagination button:hover {
            background-color: #ffecdb;
        }

        .pagination button.active {
            background-color: #FF8C00;
            color: white;
        }

        /* Mobile Responsiveness */
        @media (max-width: 768px) {
            .search-input, .search-btn {
                width: 100%;
                margin-bottom: 15px;
            }

            .pagination {
                flex-direction: column;
                gap: 5px;
            }
        }
    </style>
</head>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PL Bank - Transaction History</title>
    <style>
        /* Your existing styles go here */
    </style>
</head>
<body>

    <header>
        <h1>Transaction History</h1>
    </header>

    <div class="container">
        <div class="search-form">
            <input type="text" class="search-input" placeholder="Search by description or amount">
            <button class="search-btn">Search</button>
        </div>

        <table class="transaction-table">
            <thead>
                <tr>
                    <th>Account Number</th>
                    <th>Date</th>
                    <th>Account Holder</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    // Database connection
                    $conn = new mysqli("localhost", "root", "", "pl_bank"); // Update the credentials

                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // Search functionality
                    $search = isset($_GET['search']) ? $_GET['search'] : '';
                    $where = '';
                    if ($search != '') {
                        $search = $conn->real_escape_string($search);
                        $where = "WHERE deposit_amount LIKE '%$search%' OR account_holder LIKE '%$search%'";
                    }

                    // SQL query to fetch transaction history
                    $sql = "SELECT * FROM deposits $where ORDER BY deposit_date DESC";
                    $result = $conn->query($sql);

                    // Check if any records are found
                    if ($result->num_rows > 0) {
                        // Loop through the results and display each row
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . ($row['account_number']) . "</td>";
                            echo "<td>" . ($row['deposit_date']) . "</td>";
                            echo "<td>" . ($row['account_holder']) . "</td>";
                            echo "<td>" . ($row['deposit_amount']) . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5' class='no-records'>No transactions found</td></tr>";
                    }

                    // Close the database connection
                    error_reporting(E_ALL);
ini_set('display_errors', 1);

                    $conn->close();
                ?>
            </tbody>
        </table>

        <!-- Pagination (optional, if needed) -->
        <div class="pagination">
            <button>1</button>
            <button>2</button>
            <button>3</button>
        </div>
    </div>

</body>
</html>

