<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PL BANK - Login & Application</title>
    <style>
   body {
            background: linear-gradient(135deg, #f0f0f0, #e8e8e8);
            text-align: center;
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            padding: 0;
            color: #333;
            display: flex;
            flex-direction: column; /* Flex direction to stack header, content, and footer */
            min-height: 100vh; /* Ensures the body takes up the full viewport height */
        }

        /* Style for links within credit card background */
        .credit-card-background a {
            text-decoration: center;
            font-weight: bold;
            height: min-content;
            color: white;
            background-color: #D94E30;
            padding: 5px 5px;
            border-radius: 8px;
            
            display: inline-block;
            transition: background-color 0.3s, transform 0.2s;
        }

        /* Hover effects for links */
        .credit-card-background a:hover {
            background-color: #FF5733;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }

        /* Fixed header styles */
        header {
            background: linear-gradient(to right, #FF5733, #F0A500);
            color: white;
            
            position: sticky;
            top: 50px;
            left: 0;
            right: 1000px;
            z-index: 100;
        }

        /* Fixed footer styles */
        footer {
            background: #FF5733;
            color: white;
            padding: 10px 0;
            position: flex;
            bottom: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        /* Banner styles */
        #banner {
            background: linear-gradient(to right, #FFA500, #FF8C00);
            color: white;
            padding: 20px;
            width: 100%;
            margin: 0px auto;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            opacity: 0; /* Initially hidden */
            animation: fadeInBanner 1s ease-in-out forwards; /* Animation for fade-in */
        }
        a{
            color: white;
            padding: 10px;
        }
        .a1 {
            display:ruby-base-container;
            padding: 5px 5px;
    
            text-decoration: none;
            font-weight: bold;
            border-radius: 5px;
            text-align: end;
            transition: background 0.3s;
            margin-left: 1px;
            float: inline-end;
            margin: 20px 15px; /* Center and space out footer links */
            width: 35 0px;

        }

        .a1:hover {
            background-color: none;
        }


        @keyframes fadeInBanner {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        #banner h1 {
            margin: 0;
            font-size: 1em;
        }

    

        /* Form container */
        .div2 {
            background-color: white;
            padding: 30px;
            width: 90%;
            max-width: 500px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            opacity: 0; /* Initially hidden */
            animation: fadeInForm 1s ease-in-out forwards; /* Animation for form */
        }

        @keyframes fadeInForm {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .div2 h2 {
            color: #FFA500;
            margin-bottom: 20px;
            text-align: center;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="date"],
        input[type="tel"] {
            width: calc(100% - 12px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ced4da;
            border-radius: 5px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #FFA500;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #FF8C00;
        }

        hr {
            margin: 15px 0;
            border: 0;
            border-top: 1px solid #eee;
        }

        /* Footer styles */

        footer p {
            margin: 0;
            font-size: 0.9em;
        }

        footer a {
            color: #FFA500;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline; /* Underline on hover */
        }

        /* Media Queries */
        @media (max-width: 600px) {
            #banner h1 {
                font-size: 1.5em;
            }
            #image-slider {
                width: 100%;
            }
        }
        .div2{
            margin-left: 27.9em;
        }
        :root {
            --primary-color: #FF6F00;
            --secondary-color: #FF8F00;
            --white: #ffffff;
            --light-gray: #f5f5f5;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            background-color: var(--light-gray);
        }

        .header {
            background-color: var(--primary-color);
            color: var(--white);
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 0 20px;
        }

        .deposit-form {
            background-color: var(--white);
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }

        .form-title {
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 1.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid var(--primary-color);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            margin-bottom: 0.5rem;
            color: #333;
            font-weight: bold;
        }

        input {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }

        input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 5px rgba(255,111,0,0.2);
        }

        .submit-btn {
            background-color: var(--primary-color);
            color: var(--white);
            padding: 1rem 2rem;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            font-size: 1.1rem;
            transition: background-color 0.3s ease;
        }

        .submit-btn:hover {
            background-color: var(--secondary-color);
        }

        .message {
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 4px;
            text-align: center;
            font-weight: bold;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .home-link {
            display: block;
            text-align: center;
            margin-top: 1rem;
            color: var(--primary-color);
            text-decoration: none;
            font-weight: bold;
        }

        .home-link:hover {
            color: var(--secondary-color);
        }

        .amount-info {
            font-size: 0.9rem;
            color: #666;
            margin-top: 0.5rem;
        }

        @media (max-width: 768px) {
            .container {
                margin: 1rem auto;
            }

            .deposit-form {
                padding: 1.5rem;
            }
        }
    :root {
        --primary-color: #FF6F00;
        --secondary-color: #FF8F00;
        --white: #ffffff;
        --light-gray: #f5f5f5;
        --dark-gray: #333;
    }

    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
        font-family: 'Poppins', sans-serif;
    }

    body {
        background: linear-gradient(135deg, #FF6F00, #FF8F00);
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        padding: 20px;
    }

    .container {
        max-width: 800px;
        width: 100%;
        padding: 30px;
        background-color: rgba(255, 255, 255, 0.9);
        border-radius: 12px;
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        text-align: center;
        animation: fadeIn 0.8s ease-in-out;
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-10px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .form-title {
        font-size: 24px;
        font-weight: bold;
        color: var(--primary-color);
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 2px solid var(--primary-color);
        display: inline-block;
    }

    .form-group {
        margin-bottom: 1.5rem;
        text-align: left;
    }

    label {
        display: block;
        font-weight: bold;
        margin-bottom: 8px;
        color: var(--dark-gray);
    }

    input {
        width: 100%;
        padding: 12px;
        border: 2px solid #ddd;
        border-radius: 8px;
        font-size: 1rem;
        transition: all 0.3s ease-in-out;
    }

    input:focus {
        border-color: var(--primary-color);
        box-shadow: 0 0 10px rgba(255, 111, 0, 0.3);
        outline: none;
    }

    .submit-btn {
        background: linear-gradient(45deg, var(--primary-color), var(--secondary-color));
        color: var(--white);
        padding: 12px;
        font-size: 1.2rem;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: all 0.3s ease-in-out;
        width: 100%;
        font-weight: bold;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    .submit-btn:hover {
        background: linear-gradient(45deg, var(--secondary-color), var(--primary-color));
        transform: scale(1.05);
    }

    .message {
        padding: 15px;
        font-weight: bold;
        border-radius: 8px;
        text-align: center;
        margin-bottom: 20px;
    }

    .success {
        background-color: #d4edda;
        color: #155724;
    }

    .error {
        background-color: #f8d7da;
        color: #721c24;
    }

    .home-link {
        display: inline-block;
        margin-top: 15px;
        font-size: 16px;
        color: var(--primary-color);
        font-weight: bold;
        text-decoration: none;
        transition: color 0.3s ease-in-out;
    }

    .home-link:hover {
        color: var(--secondary-color);
    }

    @media (max-width: 768px) {
        .container {
            padding: 20px;
        }

        .submit-btn {
            font-size: 1rem;
        }}
    </style>
</head>

<body><header>
    <div class="credit-card-background">
        <h3>PL BANK Credit Cards</h3>
         <div class="a1">
        <abbr title="Back to Credit Card Home page."><a href="pl_bank.php"><h5>⇚</h5></a></abbr>
         <a href="pro_pictur.html">Explore Our Cards</a>
            <a href="pro_aces.php">Benefits</a>
            <a href="pro_cre_r.php">Offers</a>
            <a href="pro_login.php">Apply now</a>
          
            <a href="pro_crdit_re.html">Rules</a>
        </div>
    </div>
    </header>
    <div class="div2">
        <form action="pro_insert.php" method="post" id="di">
            <h2>Get Started with Your Application</h2>
            <label for="name">Name:</label>
            <input type="text" name="name" placeholder="Enter Your Name" required>
            <hr>
            <label for="d_b">Date of Birth:</label>
            <input type="date" name="d_b" required>
            <hr>
            <label for="pan">PAN:</label>
            <input type="text" name="pan" placeholder="PAN" required>
            <hr>
            <label for="ph_num">Phone Number:</label>
            <input type="tel" name="ph_num" placeholder="Enter Your Mobile Number" required>
            <hr>
            <label for="address">Address:</label>
            <input type="text" name="address" placeholder="Enter Your Address" required>
            <hr>
            <input type="submit" value="Continue">
        </form>
    </div>

    <footer>
        <p>&copy; 2024 PL BANK. All rights reserved. | <a href="#">Privacy Policy</a> | <a href="#">Terms of Service</a></p>
    </footer>

    <script>
        // JavaScript for image slider
        let slideIndex = 0;
        const slides = document.querySelectorAll('#image-slider img');

        function showSlide() {
            for (let i = 0; i < slides.length; i++) {
                slides[i].classList.remove('active');
            }
            slideIndex++;
            if (slideIndex >= slides.length) {
                slideIndex = 0;
            }
            slides[slideIndex].classList.add('active');
        }

        setInterval(showSlide, 3000);
    </script>
</body>
</html>
