<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fetch User Data</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background: linear-gradient(135deg, #f0f0f0, #e8e8e8);
            margin: 0;
            padding: 0;
            text-align: center;
        }

        header {
            background: linear-gradient(to right, #FF5733, #F0A500);
            color: white;
            padding: 15px;
            font-size: 20px;
            font-weight: bold;
            text-align: center;
        }

        .container {
            margin-top: 30px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        table {
            width: 90%;
            max-width: 1000px;
            border-collapse: collapse;
            margin: 20px 0;
            background: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 10px;
            overflow: hidden;
        }

        th, td {
            padding: 15px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #FF9100;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1c27b;
            transition: 0.3s ease-in-out;
        }

        p {
            font-size: 18px;
            font-weight: bold;
            color: #333;
        }

        footer {
            margin-top: 30px;
            background: #FF5733;
            color: white;
            text-align: center;
            padding: 10px 0;
        }

        .back-button {
            background: #FF5733;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 16px;
            margin-top: 20px;
            display: inline-block;
            transition: background 0.3s;
        }

        .back-button:hover {
            background: #c4421d;
        }
    </style>
</head>
<body>

<header>
    <h3>PL Credit Cards Details</h3>
    <h3>Fetched User Data</h3>
</header>

<div class="container">

<?php
$conn = new mysqli("localhost", "root", "", "pl_bank");
if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM Credit_cards";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table><tr><th>Name</th><th>Date of Birth</th><th>Mobile No</th><th>Address</th><th>PAN</th></tr>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>" . htmlspecialchars($row["NAME"]) . "</td><td>" . htmlspecialchars($row["date_of_birth"]) . "</td><td>" . htmlspecialchars($row["mobile_no"]) . "</td><td>" . htmlspecialchars($row["address"]) . "</td><td>" . htmlspecialchars($row["pan"]) . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "<p>No records found!</p>";
}

$conn->close();
?>

<a href="javascript:history.back()" class="back-button">Go Back</a>

</div>

<footer>
    <p>© 2024 PL Bank. All rights reserved.</p>
</footer>

</body>
</html>
