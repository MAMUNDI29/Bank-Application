<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>PL Bank Credit Card Showcase</title>
    <style>
        body {
            background: url('background.jpg') no-repeat center center/cover;
            font-family: 'Montserrat', sans-serif;
            margin: 0;
            padding: 0;
            color: #333;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background: linear-gradient(to right, #ff6600, #ff9933);
            color: white;
            padding: 15px 0;
            text-align: center;
            font-size: 1.8em;
            font-weight: bold;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }

        .nav-links {
            display: flex;
            justify-content: center;
            gap: 15px;
            padding: 10px 0;
        }

        .nav-links a {
            text-decoration: none;
            color: white;
            background: #ff6600;
            padding: 12px 18px;
            border-radius: 8px;
            transition: all 0.3s;
            font-weight: bold;
        }

        .nav-links a:hover {
            background: #ff3300;
            transform: translateY(-2px);
        }

        .content {
            padding: 50px 20px;
            flex: 1;
            text-align: center;
            background: rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            margin: 20px;
        }

        .cards-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        .card-box {
            background: white;
            border-radius: 12px;
            box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.15);
            overflow: hidden;
            width: 300px;
            transition: transform 0.3s, box-shadow 0.3s;
            border: 3px solid #ff6600;
        }

        .card-box:hover {
            transform: translateY(-5px);
            box-shadow: 0px 15px 30px rgba(0, 0, 0, 0.3);
        }

        .card-box img {
            width: 100%;
            height: auto;
        }

        .card-content {
            padding: 20px;
        }

        .card-title {
            font-size: 1.5em;
            color: #ff3300;
            margin-bottom: 10px;
        }

        .card-desc {
            font-size: 1em;
            color: #555;
            line-height: 1.6;
        }

        footer {
            background: #ff3300;
            color: white;
            text-align: center;
            padding: 15px;
            font-size: 1.1em;
        }
    </style>
</head>
<body>
    <header>
        PL BANK Credit Cards
        <div class="nav-links">
            <a href="pl_bank.php">Home</a>
            <a href="pro_pictur.html">Explore</a>
            <a href="pro_aces.php">Benefits</a>
            <a href="pro_cre_r.php">Offers</a>
            <a href="pro_login.php">Apply Now</a>
            <a href="pro_crdit_re.html">Rules</a>
        </div>
    </header>

    <div class="content">
        <h2>Choose the Best Credit Card for You</h2>
        <div class="cards-container">
            <div class="card-box">
                <img src="images.jpg" alt="Instant Credit Access" />
                <div class="card-content">
                    <h3 class="card-title">Instant Credit Access</h3>
                    <p class="card-desc">Gain immediate access to a line of credit. Flexible repayment options available.</p>
                </div>
            </div>
            <div class="card-box">
                <img src="download (1).jpg" alt="Rewards Programs" />
                <div class="card-content">
                    <h3 class="card-title">Exclusive Rewards</h3>
                    <p class="card-desc">Earn points, cashback, and discounts on every purchase. Enjoy special partner offers.</p>
                </div>
            </div>
            <div class="card-box">
                <img src="download (2).jpg" alt="Build Your Credit" />
                <div class="card-content">
                    <h3 class="card-title">Build Your Credit</h3>
                    <p class="card-desc">Improve your credit score with responsible card usage. Access better financial opportunities.</p>
                </div>
            </div>
        </div>
    </div>

    <footer>
        © 2024 PL Bank. All rights reserved.
    </footer>
</body>
</html>
