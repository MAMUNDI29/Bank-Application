<?php
$conn = new mysqli("localhost", "root", "", "pl_bank");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['table'])) {
    $table = $_GET['table'];
    $query = "SELECT * FROM $table";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        echo "<h2>" . ucfirst($table) . "</h2>";
        echo "<table><tr>";

        // Fetch column names
        while ($field = $result->fetch_field()) {
            echo "<th>" . ucfirst($field->name) . "</th>";
        }
        echo "</tr>";

        // Fetch data rows
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            foreach ($row as $data) {
                echo "<td>" . htmlspecialchars($data) . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<h2>No records found in $table</h2>";
    }
}
?>
