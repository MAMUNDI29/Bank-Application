<?php
// Database connection (you should add this)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pl_bank";

try {
    $conn = new PDO("mysql:host=$servername", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create database if not exists
    $conn->exec("CREATE DATABASE IF NOT EXISTS $dbname");
    $conn->exec("USE $dbname");
    
    // Create table if not exists
    $sql = "CREATE TABLE IF NOT EXISTS insurance_applications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        insurance_type VARCHAR(50) NOT NULL,
        coverage_amount DECIMAL(12,2) NOT NULL,
        application_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    $conn->exec($sql);
    
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Validate and sanitize input
        $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
        $insurance_type = filter_input(INPUT_POST, 'insurance_type', FILTER_SANITIZE_STRING);
        $coverage_amount = filter_input(INPUT_POST, 'coverage_amount', FILTER_SANITIZE_NUMBER_FLOAT);

        // Validate inputs
        if (empty($name) || empty($email) || empty($phone) || empty($insurance_type) || empty($coverage_amount)) {
            throw new Exception("All fields are required");
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Invalid email format");
        }

        // Insert into database
        $stmt = $conn->prepare("INSERT INTO insurance_applications (name, email, phone, insurance_type, coverage_amount) 
                              VALUES (:name, :email, :phone, :insurance_type, :coverage_amount)");
        
        $stmt->execute([
            ':name' => $name,
            ':email' => $email,
            ':phone' => $phone,
            ':insurance_type' => $insurance_type,
            ':coverage_amount' => $coverage_amount
        ]);

        $success_message = "Thank you for your insurance inquiry. Our team will contact you shortly.";
        
    } catch (Exception $e) {
        $error_message = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insurance Services</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            background-color: #f4f4f4;
        }

        .header {
            background-color: #F06B23;
            color: white;
            padding: 1rem;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .insurance-form {
            max-width: 600px;
            margin: 20px auto;
            padding: 30px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #333;
        }

        input[type="text"],
        input[type="email"],
        input[type="tel"],
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            transition: border-color 0.3s ease;
        }

        input:focus,
        select:focus {
            border-color: #F06B23;
            outline: none;
            box-shadow: 0 0 5px rgba(240,107,35,0.2);
        }

        .submit-btn {
            background-color: #F06B23;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
            transition: background-color 0.3s ease;
        }

        .submit-btn:hover {
            background-color: #d85d1a;
        }

        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
            text-align: center;
        }

        .success-message {
            background-color: #4CAF50;
            color: white;
        }

        .error-message {
            background-color: #f44336;
            color: white;
        }

        .exit-btn {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #666;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
            width: fit-content;
        }

        .exit-btn:hover {
            background-color: #555;
        }

        @media (max-width: 768px) {
            .insurance-form {
                margin: 10px;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Insurance Services</h1>
    </div>
    <div class="container">
        <?php if (isset($success_message)): ?>
            <div class="message success-message">
                <?php echo htmlspecialchars($success_message); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
            <div class="message error-message">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>

        <div class="insurance-form">
            <h2>Insurance Application Form</h2>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-group">
                    <label for="name">Full Name:</label>
                    <input type="text" id="name" name="name" required 
                           value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>">
                </div>

                <div class="form-group">
                    <label for="email">Email Address:</label>
                    <input type="email" id="email" name="email" required
                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                </div>

                <div class="form-group">
                    <label for="phone">Phone Number:</label>
                    <input type="tel" id="phone" name="phone" required pattern="[0-9]{10}"
                           title="Please enter a valid 10-digit phone number"
                           value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
                </div>

                <div class="form-group">
                    <label for="insurance_type">Insurance Type:</label>
                    <select id="insurance_type" name="insurance_type" required>
                        <option value="">Select Insurance Type</option>
                        <option value="life" <?php echo (isset($_POST['insurance_type']) && $_POST['insurance_type'] == 'life') ? 'selected' : ''; ?>>Life Insurance</option>
                        <option value="health" <?php echo (isset($_POST['insurance_type']) && $_POST['insurance_type'] == 'health') ? 'selected' : ''; ?>>Health Insurance</option>
                        <option value="motor" <?php echo (isset($_POST['insurance_type']) && $_POST['insurance_type'] == 'motor') ? 'selected' : ''; ?>>Motor Insurance</option>
                        <option value="home" <?php echo (isset($_POST['insurance_type']) && $_POST['insurance_type'] == 'home') ? 'selected' : ''; ?>>Home Insurance</option>
                        <option value="travel" <?php echo (isset($_POST['insurance_type']) && $_POST['insurance_type'] == 'travel') ? 'selected' : ''; ?>>Travel Insurance</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="coverage_amount">Coverage Amount:</label>
                    <select id="coverage_amount" name="coverage_amount" required>
                        <option value="">Select Coverage Amount</option>
                        <option value="500000" <?php echo (isset($_POST['coverage_amount']) && $_POST['coverage_amount'] == '500000') ? 'selected' : ''; ?>>₹5 Lakhs</option>
                        <option value="1000000" <?php echo (isset($_POST['coverage_amount']) && $_POST['coverage_amount'] == '1000000') ? 'selected' : ''; ?>>₹10 Lakhs</option>
                        <option value="2000000" <?php echo (isset($_POST['coverage_amount']) && $_POST['coverage_amount'] == '2000000') ? 'selected' : ''; ?>>₹20 Lakhs</option>
                        <option value="5000000" <?php echo (isset($_POST['coverage_amount']) && $_POST['coverage_amount'] == '5000000') ? 'selected' : ''; ?>>₹50 Lakhs</option>
                        <option value="10000000" <?php echo (isset($_POST['coverage_amount']) && $_POST['coverage_amount'] == '10000000') ? 'selected' : ''; ?>>₹1 Crore</option>
                    </select>
                </div>

                <button type="submit" class="submit-btn">Submit Application</button>
            </form>
        </div>
        <a href="FRONT.html" class="exit-btn">← Back to Home</a>
    </div>
</body>
</html>