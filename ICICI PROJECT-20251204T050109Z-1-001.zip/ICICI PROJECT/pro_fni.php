<?php
session_start();
$conn = new mysqli("localhost", "root", "", "pl_bank");
if ($conn->connect_error) {
    die("Connection Failed: " . $conn->connect_error);
}

if (isset($_SESSION['name'])) {
    $name = htmlspecialchars($_SESSION['name']);
    $creditCardNumber = str_pad(mt_rand(0, 999999999), 9, '0', STR_PAD_LEFT); // Generate 9-digit number

    echo "<!DOCTYPE html>
    <html lang='en'>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <title>Application Successful</title>
        <link rel='stylesheet' href='style.css'>
        <style>
            body {
                font-family: 'Montserrat', sans-serif;
                background: linear-gradient(135deg, #f0f0f0, #e8e8e8);
                text-align: center;
                padding: 50px;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                height: 100vh;
            }

            .container {
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
                max-width: 400px;
                width: 100%;
            }

            h1 {
                color: #FF5733;
            }

            p {
                font-size: 18px;
                color: #333;
            }

            .back-button {
                margin-top: 20px;
                background: #FF5733;
                color: white;
                padding: 10px 20px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                text-decoration: none;
                font-size: 16px;
                display: inline-block;
                transition: background 0.3s;
            }

            .back-button:hover {
                background: #c4421d;
            }
        </style>
    </head>
    <body>
        <div class='container'>
            <h1>Congratulations, $name!</h1>
            <p>Your application has been submitted successfully.</p>
            <p>Your credit card number is: <strong>$creditCardNumber</strong></p>
            <p>You will receive your card in the mail within 2 days.</p>
            <a href='javascript:history.back()' class='back-button'>Go Back</a>
        </div>
    </body>
    </html>";

    // Optionally log the generated credit card number in the database
    $stmt = $conn->prepare("UPDATE Credit_cards SET credit_card = ? WHERE NAME = ?");
    $stmt->bind_param("ss", $creditCardNumber, $_SESSION['name']);
    $stmt->execute();
    $stmt->close();
} else {
    header("Location: pro_login.php"); // Redirect if session is not set
    exit();
}

$conn->close();
?>
